package aa;

public class InventarioDefinir {

	
}