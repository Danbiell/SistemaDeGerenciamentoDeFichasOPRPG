package aa;

public class FichaCriar {

    String nome = null, criador = null, origem = null, descOrigem = null, classe = null, historico = null, hobbies = null;
    Integer nivel = null, nex = null, forca = null, agilidade = null, vigor = null, intelecto = null, presenca = null, qtdPontosRestantes = null, pv = null, pe = null, san = null, idade = null;

    public void IniciarCriacaoFicha() {


        // criar objeto e aprender a usar .this e getNome()

        MenuCriarFicha();
    }

    public void MenuCriarFicha() {
        System.out.print("");
    }

    public void MenuGerais() {

    }
}