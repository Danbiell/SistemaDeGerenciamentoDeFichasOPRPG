package aa;

public class FichaDeletar {

	
}